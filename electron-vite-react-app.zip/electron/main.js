import { app, BrowserWindow, screen } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function createWindowOnMonitor(monitor) {
  const win = new BrowserWindow({
    x: monitor.bounds.x,
    y: monitor.bounds.y,
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  if (process.env.VITE_DEV_SERVER_URL) {
    win.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    win.loadFile(path.join(__dirname, '../dist/index.html'));
  }
}

app.whenReady().then(() => {
  const displays = screen.getAllDisplays();
  const targetMonitor = displays[1] || displays[0]; // Usa segundo monitor si existe
  createWindowOnMonitor(targetMonitor);
});
