import { contextBridge } from 'electron';

contextBridge.exposeInMainWorld('electronAPI', {
  // Aquí puedes exponer funciones si lo deseas
});
